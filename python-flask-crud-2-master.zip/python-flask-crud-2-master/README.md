![featured-image](https://raw.githubusercontent.com/andela-mnzomo/project-dream-team-two/master/flask-crud-part-two.jpg)

The code for Part Two of my three-part tutorial, *Build a CRUD Web App With Python and Flask*.
