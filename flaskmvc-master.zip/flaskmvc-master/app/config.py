config = {}
config['MONGO_DBNAME'] = 'flaskblog'
config['MONGO_URI'] = 'mongodb://localhost:27017/flaskblog'
config['BASE_URL'] = "http://127.0.0.1:5000/"